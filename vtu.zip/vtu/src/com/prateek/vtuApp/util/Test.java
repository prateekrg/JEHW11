package com.prateek.vtuApp.util;

import com.prateek.vtuApp.dao.Vtu_dao;
import com.prateek.vtuApp.dto.Vtu;

public class Test {

	public static void main(String[] args) {
		
		Vtu_dao dao=new Vtu_dao();
		dao.getDetailsByBranch("cs");
		dao.getCount();
		//dao.getMarksBybranch("cs");
		//dao.getAllDetails();
		//dao.updateSemByUsn("Passed out","2sr12ec065");
		
		
	}
}
