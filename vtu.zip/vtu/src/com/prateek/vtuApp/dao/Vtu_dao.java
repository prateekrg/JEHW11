package com.prateek.vtuApp.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prateek.app.HibernateUtil;
import com.prateek.vtuApp.dto.Vtu;

public class Vtu_dao {

	public void saveDetails(Vtu v) {
	System.out.println("-----saving----");
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction tx=session.beginTransaction();
		
		try {
			session.save(v);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}finally{
			session.close();
		}
		System.out.println("-----saved----");
	}

	public void getDetailsByBranch(String branch) {
		Session session=HibernateUtil.getSessionFactory().openSession();
		Query qry=session.getNamedQuery("Vtu.getDetailsByBranch");
		qry.setParameter("brnch",branch);
		Vtu v=(Vtu) qry.uniqueResult();
		
		System.out.println(v.getUsn()+"\t"+v.getSem());
		
		
		
	}

	public void getCount() {

		Session session=HibernateUtil.getSessionFactory().openSession();
       Query qry=session.getNamedQuery("Vtu.getCount");
      long count=(long) qry.uniqueResult();
       System.out.println(count);
       
		
	}

	public void getMarksBybranch(String branch) {

		Session session=HibernateUtil.getSessionFactory().openSession();
		String syntx="select v.marks from Vtu v where v.branch='"+branch+"'";
		   Query qry=session.createQuery(syntx);
		      int marks=(int) qry.uniqueResult();
		       System.out.println(marks);
		
		
	}

	public void getAllDetails() {
		Session session=HibernateUtil.getSessionFactory().openSession();
		String syntx=" from Vtu v";
		 Query qry=session.createQuery(syntx);
		List l= qry.list();
		Iterator i=l.iterator();
		
		while(i.hasNext())
		{
			Object ob=i.next();
			Vtu v=(Vtu) ob;
			System.out.println(v.getUsn());
		}
		
	}

	public void updateSemByUsn(String sem, String usn) {
		Session session=HibernateUtil.getSessionFactory().openSession();
		String syntx="update Vtu v set v.sem='"+sem+"' where v.usn='"+usn+"'";
		Query qry=session.createQuery(syntx);
		qry.executeUpdate();
		session.close();
	}

}
