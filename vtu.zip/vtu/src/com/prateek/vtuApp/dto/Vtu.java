package com.prateek.vtuApp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "vtu")
@NamedQueries({
	@NamedQuery(name="Vtu.getDetailsByBranch",query="from Vtu v where v.branch=:brnch  "),
	@NamedQuery(name="Vtu.getDetailsByBranch",query="select count(*) from Vtu v")
})
public class Vtu implements Serializable {

	@Id
	@GenericGenerator(name = "Vtu_id_seq", strategy = "increment")
	@GeneratedValue(generator = "Vtu_id_seq")
	@Column(name = "id")
	private int id;

	@Column(name = "usn")
	private String usn;

	@Column(name = "branch")
	private String branch;

	@Column(name = "sem")
	private String sem;

	@Column(name = "marks")
	private int marks;

	@Column(name = "subcode")
	private String subcode;

	
	public Vtu() {
		System.out.println(this.getClass().getName());
		
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getUsn() {
		return usn;
	}


	public void setUsn(String usn) {
		this.usn = usn;
	}


	public String getBranch() {
		return branch;
	}


	public void setBranch(String branch) {
		this.branch = branch;
	}


	public String getSem() {
		return sem;
	}


	public void setSem(String sem) {
		this.sem = sem;
	}


	public int getMarks() {
		return marks;
	}


	public void setMarks(int marks) {
		this.marks = marks;
	}


	public String getSubcode() {
		return subcode;
	}


	public void setSubcode(String subcode) {
		this.subcode = subcode;
	}
	
	
	
}
