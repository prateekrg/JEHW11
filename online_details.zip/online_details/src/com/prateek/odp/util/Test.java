package com.prateek.odp.util;

import com.prateek.odp.dao.online_dtails_dao;
import com.prateek.odp.dto.Online_Details;

public class Test {

	public static void main(String[] args) {
		
		
		Online_Details o=new Online_Details();
		o.setId(1);
		o.setName("abhi");
		o.setEmail("abhi@gmail.com");
		o.setAdress("Belagvi");
		o.setPhno(9742663304l);
		
		online_dtails_dao dao=new online_dtails_dao();
		dao.save(o);
		
	}
}
