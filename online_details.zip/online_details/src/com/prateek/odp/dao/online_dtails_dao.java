package com.prateek.odp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.prateek.odp.dto.Online_Details;

public class online_dtails_dao {

	public void save(Online_Details o) {
	System.out.println("----saving details----");
	Configuration cfg=new Configuration();
	cfg.configure();
	cfg.addAnnotatedClass(Online_Details.class);
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	Transaction tx=session.beginTransaction();
	session.save(o);
	tx.commit();
	
	System.out.println("----details saved-----");
		
	}

}
