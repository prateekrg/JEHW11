package com.prateek.ecomApp.util;

import com.prateek.ecomApp.dao.Ecommerce_dao;
import com.prateek.ecomApp.dto.Ecommerce_Details;

public class Test {

	public static void main(String[] args) {
		
		Ecommerce_Details cd=new Ecommerce_Details();
	
		cd.setItemname("Iphone");
		cd.setCost(70000);
		cd.setDescription("very expensive");
		cd.setPaythrogh("credit card");
		
		Ecommerce_dao dao=new Ecommerce_dao();
		dao.saveDetails(cd);
		
		//dao.getItemDetilsPk(4);
		//dao.updateCostByPk(4);
		
	//	dao.deleteDataByPk(4);
		
		
	}
}
