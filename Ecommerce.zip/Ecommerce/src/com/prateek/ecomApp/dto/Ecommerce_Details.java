package com.prateek.ecomApp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="ecommerce")
public class Ecommerce_Details implements Serializable {

	
	@Id
	@GenericGenerator(name="Ecommerce_Details_id_seq",strategy="increment")
	@GeneratedValue(generator="Ecommerce_Details_id_seq")
	@Column(name="id")
	private int id;
	
	@Column(name="itemname")
	private String itemname;
	
	@Column(name="cost")
	private double cost;
	
	@Column(name="description")
	private String description;
	
	@Column(name="paythrough")
	private String paythrogh;
	
	public Ecommerce_Details()
	{
		System.out.println(this.getClass().getSimpleName()+" is created......");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPaythrogh() {
		return paythrogh;
	}

	public void setPaythrogh(String paythrogh) {
		this.paythrogh = paythrogh;
	}
	
	
}
