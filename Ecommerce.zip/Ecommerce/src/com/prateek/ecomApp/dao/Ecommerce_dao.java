package com.prateek.ecomApp.dao;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.prateek.ecomApp.dto.Ecommerce_Details;

public class Ecommerce_dao {

	

	public void getItemDetilsPk(int pk) {

		System.out.println("---fetching details-----");
		Configuration cfg=new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Ecommerce_Details.class);
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Ecommerce_Details ed=session.get(Ecommerce_Details.class, pk);
		System.out.println(ed.getItemname()+"\t"+ed.getPaythrogh());
		
		
	}

	public void updateCostByPk(int pk) {

		System.out.println("---updating details-----");
		Configuration cfg=new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Ecommerce_Details.class);
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Ecommerce_Details ed=session.get(Ecommerce_Details.class, pk);
		ed.setCost(100000);
		session.update(ed);
		
		tx.commit();
		session.close();
		
		System.out.println("---details updated-----");
	}

	public void deleteDataByPk(int pk) {
		System.out.println("---deleting details-----");
		Configuration cfg=new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Ecommerce_Details.class);
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Ecommerce_Details ed=session.get(Ecommerce_Details.class, pk);
		
		session.delete(ed);
		
		tx.commit();
		session.close();
		
		System.out.println("---details deleted-----");
	}

	public void saveDetails(Ecommerce_Details cd) {
		Configuration cfg=new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Ecommerce_Details.class);
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(cd);
		tx.commit();
		session.close();
		
	}

}
