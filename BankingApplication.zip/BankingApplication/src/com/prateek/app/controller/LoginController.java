package com.prateek.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.prateek.app.dto.LoginEntity;

@Component
@RequestMapping("/")
public class LoginController {


	/*@RequestMapping(value="/login.do" ,method={RequestMethod.GET,RequestMethod.POST})
	public String login(HttpServletRequest request)
	{
		System.out.println("inside login.....");
		
		
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        
        System.out.println(username);
        System.out.println(password);
		
        request.setAttribute("uname", username);
        
        
        return "/home.jsp";
	}*/
	
	/*@RequestMapping(value="/login.do" ,method={RequestMethod.GET,RequestMethod.POST})
	public String login(@RequestParam("username")String usname,
			@RequestParam("password")String password,
			HttpServletRequest request)
	{
		System.out.println("inside login.....");
		
		
       
        System.out.println(usname);
        System.out.println(password);
		
        request.setAttribute("uname", usname);
        
        
        return "/home.jsp";
	}*/
	
	@RequestMapping(value="/login.do" ,method={RequestMethod.GET,RequestMethod.POST})
	public String login(@ModelAttribute LoginEntity entity, HttpServletRequest request,HttpSession session)
	{
		System.out.println("inside login.....");
        session.setAttribute("uname", entity.getUsername());
        
        
        return "/home.jsp";
	}
	
	
}
