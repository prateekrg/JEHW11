package com.prateek.bankApp.dto;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.engine.internal.Cascade;

@Entity
public class Bank {

	@Id
	@GenericGenerator(name = "bank_id_seq", strategy = "increment")
	@GeneratedValue(generator = "bank_id_seq")
	private int id;
	private String name;
	private String branch;
	private String ifsc;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,targetEntity=Customer.class,mappedBy="bank")
	@PrimaryKeyJoinColumn
	private Collection<Customer>  customer;
	
	public Bank() {
		System.out.println(this.getClass().getSimpleName()+" is created....");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public Collection<Customer> getCustomer() {
		return customer;
	}

	public void setCustomer(Collection<Customer> customer) {
		this.customer = customer;
	}
	
}
