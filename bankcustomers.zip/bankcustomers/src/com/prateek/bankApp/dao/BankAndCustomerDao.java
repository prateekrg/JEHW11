package com.prateek.bankApp.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prateek.app.HibernateUtil;
import com.prateek.bankApp.dto.Bank;

public class BankAndCustomerDao {

	public void saveBank(Bank b1) {
		System.out.println("---saving details----");
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction tx=session.beginTransaction();
		try {
			
			session.save(b1);
		
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}finally{
			session.close();
		}
		b1.setName("icici");
		System.out.println("----saved-----");
		
	}

}
