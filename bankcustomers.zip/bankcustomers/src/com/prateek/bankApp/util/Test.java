package com.prateek.bankApp.util;

import java.util.ArrayList;
import java.util.Collection;

import com.prateek.bankApp.dao.BankAndCustomerDao;
import com.prateek.bankApp.dto.Bank;
import com.prateek.bankApp.dto.Customer;

public class Test {

	public static void main(String[] args) {
		
		Bank b1=new Bank();
		b1.setName("sbi");
		b1.setBranch("rajajinagar");
		b1.setIfsc("sbin000001");
		
		
		
		Customer c1=new Customer();
		c1.setAccno(200091234l);
		c1.setName("roopa");
		c1.setType("savings");
		c1.setMobileno(81979660720l);
		c1.setMailid("rrpa@gmail.com");
		c1.setBal(100);
		c1.setBank(b1);
		
		Customer c2=new Customer();
		c2.setAccno(540580891235l);
		c2.setName("keertana");
		c2.setType("savings");
		c2.setMobileno(9591577825l);
		c2.setMailid("keeru@gmail.com");
		c2.setBal(3000);
		c2.setBank(b1);
		
		Collection c=new ArrayList();
		c.add(c1);
		c.add(c2);
		
		b1.setCustomer(c);
		
		BankAndCustomerDao dao=new BankAndCustomerDao();
		dao.saveBank(b1);		
		
	}
}
