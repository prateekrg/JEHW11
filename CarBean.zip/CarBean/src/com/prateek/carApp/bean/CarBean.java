package com.prateek.carApp.bean;

public class CarBean {

	public CarBean() {
		System.out.println(this.getClass().getSimpleName()+" is created....");
	}
	
	public void travel()
	{
		System.out.println("shriya is traveeling with 1000kn/hr");
	}
	
	
}
