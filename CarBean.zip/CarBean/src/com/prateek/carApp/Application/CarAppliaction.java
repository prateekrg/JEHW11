package com.prateek.carApp.Application;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.prateek.carApp.bean.CarBean;

public class CarAppliaction {

	public static void main(String[] args) {

		
	//creating container using ApplicationContaxt to read xml
	  
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		CarBean bean=context.getBean("car1",CarBean.class);
		bean.travel();
		
		CarBean bean1=context.getBean("car2",CarBean.class);
		bean1.travel();
	}
	
}
